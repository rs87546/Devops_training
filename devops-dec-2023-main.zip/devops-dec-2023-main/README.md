## My LinkedIn Profile
https://www.linkedin.com/in/jeganathan-swaminathan-2a6a6a6/

## My Blogs
https://medium.com/tektutor
https://medium.com/@jegan_50867/docker-overview-be840f727b3
https://medium.com/tektutor/container-engine-vs-container-runtime-667a99042f3
https://medium.com/@jegan_50867/docker-commands-ba19387383b4
https://medium.com/tektutor/ci-cd-with-maven-github-docker-jenkins-aca28c252fec

## My YouTube channel
https://www.youtube.com/@JeganathanSwaminathan

## Kindly complete your pre-test from your RPS Lab machine
https://app.mymapit.in/code4/tiny/Dm7Lz1

RPS Cloud Login you would have received via email, which looks like 23MAN3489_UXX
<pre>
Password is Password@1
</pre>
You may be prompted to change the password, you may change the password to rps@12345 as it would be convenient to use a common password while troubleshooting during the training.

Login credentials for your RPS CentOS Lab machine
<pre>
username - rps
password - rps@12345
</pre>

Once you all complete the test, leave a confirmation message so that we can start the training.
