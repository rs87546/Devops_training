#include "hello.h"

int main() {

	Hello hello;
	std::cout << hello.sayHello() << std::endl;

	return 0;
}
