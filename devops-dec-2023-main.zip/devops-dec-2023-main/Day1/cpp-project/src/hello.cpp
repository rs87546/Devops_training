#include "hello.h"

std::string Hello::sayHello() {
	return "Hello C++!";
}
