#include <iostream>

class Hello {
public:
	std::string sayHello();
};
