package org.tektutor;

public class DataAccessLayer {

	public String getModuleName() {
		return "DataAccessLayer";
	}

}
