## Cloning this github training repo
```
cd ~
git clone https://github.com/tektutor/devops-malaysia-2024.git
cd devops-malaysia-2024
```
