package org.tektutor;

public class RPNCalculator {

	public double evaluate ( String rpnMathExpression ) {

		return 25.0;

	}

}
