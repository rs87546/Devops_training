display(spark.range(10))

