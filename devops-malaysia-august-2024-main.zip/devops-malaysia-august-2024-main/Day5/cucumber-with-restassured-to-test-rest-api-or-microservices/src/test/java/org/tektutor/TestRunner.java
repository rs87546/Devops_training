package org.tektutor;

import org.junit.runner.RunWith;
import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;

@CucumberOptions(features = ".")
@RunWith(Cucumber.class)
public class TestRunner {

}